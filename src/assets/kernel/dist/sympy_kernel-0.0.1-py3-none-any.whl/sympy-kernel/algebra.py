import sympy

def cool_func():
    print("Sympy cool")