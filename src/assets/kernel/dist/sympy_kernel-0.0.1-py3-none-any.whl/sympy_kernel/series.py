from sympy import *

def series_expansion(expr):
    sx = series(expr)
    return sx